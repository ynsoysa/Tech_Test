The deliverable includes;
1. Java source (including unit tests)
2. Runnable jar which launches Java swing standalone UI. If the application does not launch by double clicking on the robot.jar please run the following
command on you command line from the location where robot.jar is.
java -jar robot.jar